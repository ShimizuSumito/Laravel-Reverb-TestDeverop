import Echo from 'laravel-echo';

import Pusher from 'pusher-js';
window.Pusher = Pusher;

const echoInstance = new Echo({
    broadcaster: 'reverb',
    key: "khbikvphwktebnlfmnsq",
    wsHost: "localhost",
    wsPort: 8080,
    //wssPort: 8080,
    forceTLS: false,
    enabledTransports: ['ws'],
});

export default echoInstance;