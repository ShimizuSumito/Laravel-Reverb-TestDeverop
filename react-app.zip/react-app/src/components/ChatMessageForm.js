// src/components/ChatMessageForm.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import echo from '../resources/js/echo'; // Echo設定ファイルのインポート

const ChatMessageForm = () => {
    const [text, setText] = useState('');
    const [messages, setMessages] = useState([]);
    useEffect(() => {
        const channel = echo.channel('chat')
            .listen('TestEvent', (event) => {
            axios.get('http://localhost:8000/api/messages')
            .then(response => setMessages(response.data));
                console.log("broadcast");
            });

        axios.get('http://localhost:8000/api/messages')
        .then(response => setMessages(response.data));

        return () => {
            channel.stopListening('TestEvent');
            echo.leaveChannel('chat'); // コンポーネントのクリーンアップ時にチャンネルを離脱
        };
    }, []);

    const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            await axios.post('http://localhost:8000/api/chat-messages', { text });
            setText(''); // フォームをリセット
            alert('Message added successfully!');
        } catch (error) {
            console.error('There was an error!', error);
            alert('Error adding message.');
        }
    };

    const broadcast = () => {
        axios.get('http://localhost:8000/api/broadcast');
        console.log("broadcast");
    }

    return (
        <div>
        <form onSubmit={handleSubmit}>
            <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Enter your message"
                required
            />
            <button type="submit">Add Message</button>
        </form>
        <button onClick={broadcast}>broadcast</button>

        <div>
            {messages.map((message, index) => (
                <div key={index}>{message.text}</div>
            ))}
            </div>
        </div>
    );
};

export default ChatMessageForm;
