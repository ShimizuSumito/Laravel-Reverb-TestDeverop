import logo from './logo.svg';
import './App.css';
import ChatMessageForm from './components/ChatMessageForm';

function App() {
  return (
    <div className="App">
    <h1>Chat Application</h1>
    <ChatMessageForm />
    </div>
  );
}

export default App;
